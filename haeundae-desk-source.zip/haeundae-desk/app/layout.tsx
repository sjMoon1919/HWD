import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = { title: '해운대 데스크 | 나의 의정자료실', description: '해운대구 예산·결산 및 의정자료 개인 작업 공간', manifest: '/manifest.webmanifest', icons: { icon: '/icon.svg', apple: '/icon.svg' } };
export const viewport: Viewport = { themeColor: '#302acb' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="ko"><body>{children}</body></html>; }
