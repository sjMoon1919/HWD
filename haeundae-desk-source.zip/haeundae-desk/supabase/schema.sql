-- Supabase SQL Editor에서 실행. 아래 UUID를 Auth에 직접 생성한 사용자 ID로 교체하세요.
create table public.app_owner (id uuid primary key references auth.users(id));
insert into public.app_owner(id) values ('00000000-0000-0000-0000-000000000000');
alter table public.app_owner enable row level security;
create policy "owner can read identity" on public.app_owner for select to authenticated using (id=auth.uid());
create function public.is_owner() returns boolean language sql stable security definer set search_path=public as $$select exists(select 1 from public.app_owner where id=auth.uid())$$;
revoke all on function public.is_owner() from public;
grant execute on function public.is_owner() to authenticated;
create table public.documents (
 id uuid primary key, owner_id uuid not null default auth.uid() references auth.users(id),
 name text not null, year integer not null check(year between 2000 and 2100),
 category text not null check(category in ('본예산','추경','결산','사업명세서','기금','검토보고서')),
 hash text not null, storage_path text not null, status text not null default '검토 필요', created_at timestamptz not null default now(),
 unique(owner_id,hash), unique(id,owner_id), unique(id,owner_id,year,category)
);
create table public.document_pages (
 id uuid primary key default gen_random_uuid(),document_id uuid not null,owner_id uuid not null default auth.uid(),
 page integer not null check(page>0),sheet text,text text not null,method text not null check(method in ('text','ocr','excel')),
 foreign key(document_id,owner_id) references public.documents(id,owner_id) on delete cascade, unique(document_id,page)
);
create table public.budget_rows (
 id uuid primary key default gen_random_uuid(),document_id uuid not null,owner_id uuid not null default auth.uid(),
 year integer not null,category text not null,name text not null check(length(trim(name))>0),amount bigint not null check(amount between 0 and 9007199254740991),
 hierarchy text not null default '',page integer not null,sheet text,source_text text not null,verified boolean not null default false,
 foreign key(document_id,owner_id,year,category) references public.documents(id,owner_id,year,category) on delete cascade,
 foreign key(document_id,page) references public.document_pages(document_id,page)
);
create index budget_year on public.budget_rows(owner_id,year,category,verified);
do $$declare tbl text; begin foreach tbl in array array['documents','document_pages','budget_rows'] loop
 execute format('alter table public.%I enable row level security',tbl);
 execute format('create policy owner_only on public.%I for all to authenticated using (owner_id=auth.uid() and public.is_owner()) with check (owner_id=auth.uid() and public.is_owner())',tbl);
end loop;end$$;
create function public.save_document(payload jsonb) returns uuid language plpgsql security invoker set search_path=public as $$
declare doc_id uuid := (payload->>'id')::uuid; p jsonb; r jsonb;
begin
 if not public.is_owner() then raise exception '허용된 소유자 계정이 아닙니다.'; end if;
 insert into public.documents(id,name,year,category,hash,storage_path) values(doc_id,payload->>'name',(payload->>'year')::int,payload->>'category',payload->>'hash',payload->>'storage_path');
 for p in select * from jsonb_array_elements(payload->'pages') loop
 insert into public.document_pages(document_id,page,sheet,text,method) values(doc_id,(p->>'page')::int,p->>'sheet',p->>'text',p->>'method');end loop;
 for r in select * from jsonb_array_elements(payload->'rows') loop
 insert into public.budget_rows(id,document_id,year,category,name,amount,hierarchy,page,sheet,source_text,verified) values((r->>'id')::uuid,doc_id,(payload->>'year')::int,payload->>'category',r->>'name',(r->>'amount')::bigint,r->>'hierarchy',(r->>'page')::int,r->>'sheet',r->>'source_text',false);end loop;
 return doc_id;
end$$;
revoke all on function public.save_document(jsonb) from public;
grant execute on function public.save_document(jsonb) to authenticated;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('documents','documents',false,104857600,array['application/pdf','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);
create policy private_document_storage on storage.objects for all to authenticated using(bucket_id='documents' and (storage.foldername(name))[1]=auth.uid()::text and public.is_owner()) with check(bucket_id='documents' and (storage.foldername(name))[1]=auth.uid()::text and public.is_owner());
