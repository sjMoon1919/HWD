-- schema.sql 다음에 실행. 검토 당시 데이터 및 페이지 근거를 함께 보존합니다.
create table public.reviews (
 id uuid primary key default gen_random_uuid(),owner_id uuid not null default auth.uid() references auth.users(id),
 year integer not null,content text not null,mode text not null,snapshot jsonb not null,created_at timestamptz not null default now()
);
alter table public.reviews enable row level security;
create policy owner_reviews on public.reviews for all to authenticated using(owner_id=auth.uid() and public.is_owner()) with check(owner_id=auth.uid() and public.is_owner());
