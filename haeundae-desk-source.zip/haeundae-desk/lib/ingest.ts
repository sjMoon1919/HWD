import type { BudgetRow, Category, Source } from './types';
import type { CellValue } from 'exceljs';
export async function fingerprint(file:File) { return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer()))).map(b=>b.toString(16).padStart(2,'0')).join(''); }
export function parseAmount(value:string) {
  const clean=value.replace(/[,\s원]/g,'');
  if (!/^-?\d+(\.\d+)?$/.test(clean)) throw new Error('금액은 숫자로 입력하세요.');
  const n=Number(clean); if(!Number.isSafeInteger(n)||n<0) throw new Error('금액은 0 이상의 정수(원)로 입력하세요.'); return n;
}
export async function extract(file:File,progress:(s:string)=>void):Promise<Source[]> {
  if(/\.xlsx$/i.test(file.name)) {
    const {default:ExcelJS}=await import('exceljs'); const book=new ExcelJS.Workbook();
    await book.xlsx.load(await file.arrayBuffer()); const pages:Source[]=[];
    book.eachSheet(sheet=>{const lines:string[]=[];sheet.eachRow(row=>{lines.push((row.values as CellValue[]).slice(1).map(v=>typeof v==='object'&&v!==null&&'result' in v?String(v.result):typeof v==='object'&&v!==null&&'text' in v?String(v.text):typeof v==='object'&&v!==null&&'richText' in v?v.richText.map(t=>t.text).join(''):String(v??'')).join('\t'));}); pages.push({page:pages.length+1,sheet:sheet.name,text:lines.join('\n'),method:'excel'});});
    return pages;
  }
  const pdfjs=await import('pdfjs-dist'); pdfjs.GlobalWorkerOptions.workerSrc='/pdf.worker.min.mjs';
  const pdf=await pdfjs.getDocument({data:new Uint8Array(await file.arrayBuffer()),cMapUrl:'/cmaps/',cMapPacked:true,standardFontDataUrl:'/standard_fonts/'}).promise;
  const pages:Source[]=[]; let worker:Awaited<ReturnType<typeof import('tesseract.js').createWorker>>|undefined;
  try { for(let p=1;p<=pdf.numPages;p++) {
    progress(`${p} / ${pdf.numPages} 페이지 읽는 중`); const page=await pdf.getPage(p); const content=await page.getTextContent();
    let text=''; let lastY:number|undefined;
    for(const item of content.items) { if('str' in item) { const y=item.transform[5]; if(lastY!==undefined&&Math.abs(lastY-y)>3)text+='\n'; text+=item.str+'\t';lastY=y;if(item.hasEOL){text+='\n';lastY=undefined;} } }
    let method:Source['method']='text';
    if(text.replace(/\s/g,'').length<30) {
      progress(`${p} 페이지 스캔 OCR 중 · 최초 실행 시 언어 자료 다운로드`);
      if(!worker){const {createWorker}=await import('tesseract.js');worker=await createWorker('kor+eng');}
      const viewport=page.getViewport({scale:2}); const canvas=document.createElement('canvas');canvas.width=viewport.width;canvas.height=viewport.height;
      await page.render({canvas,canvasContext:canvas.getContext('2d')!,viewport}).promise;
      text=(await worker.recognize(canvas)).data.text;method='ocr';canvas.width=0;
    }
    pages.push({page:p,text,method});page.cleanup();
  }} finally { if(worker)await worker.terminate();await pdf.destroy(); }
  return pages;
}
// 보수적으로 사업/금액 후보만 추출합니다. 회계 단위와 열 선택은 원문 대조 후 사용자가 확정합니다.
export function propose(pages:Source[],document_id:string,year:number,category:Category):BudgetRow[] {
  const result:BudgetRow[]=[];
  for(const page of pages) for(const line of page.text.split('\n')) {
    const match=line.match(/^(.{2,160}?)\s+([\d,]+)(?:\s*원)?(?:\s|$)/);
    if(!match||!/[가-힣a-zA-Z]/.test(match[1]))continue;
    const amount=Number(match[2].replace(/,/g,''));if(!Number.isSafeInteger(amount))continue;
    result.push({id:crypto.randomUUID(),document_id,year,category,name:match[1].trim(),amount,hierarchy:'',page:page.page,sheet:page.sheet,source_text:line,verified:false});
  }
  return result;
}
