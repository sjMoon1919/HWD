export const categories = ['본예산','추경','결산','사업명세서','기금','검토보고서'] as const;
export type Category = typeof categories[number];
export type Source = { page: number; text: string; method: 'text'|'ocr'|'excel'; sheet?: string };
export type BudgetRow = { id: string; document_id: string; year: number; category: Category; name: string; amount: number; hierarchy: string; page: number; sheet?: string; source_text: string; verified: boolean };
export type Doc = { id: string; name: string; year: number; category: Category; hash: string; storage_path?: string; pages: Source[]; rows: BudgetRow[]; status: string; created_at: string };
