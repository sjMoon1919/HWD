import type { BudgetRow } from './types';
export function compare(rows: BudgetRow[], year: number) {
  const sums = [year-2,year-1,year].map(y=>rows.filter(r=>r.year===y && r.verified).reduce((s,r)=>s+r.amount,0));
  return { sums, delta: sums[2]-sums[1], rate: sums[1]===0 ? null : (sums[2]-sums[1])/sums[1]*100 };
}
const normalized=(s:string)=>s.replace(/[\s\p{P}]/gu,'').toLowerCase();
function grams(s:string) { return new Set(Array.from({length:Math.max(0,s.length-1)},(_,i)=>s.slice(i,i+2))); }
export function lineage(a:BudgetRow,b:BudgetRow) {
  const x=normalized(a.name),y=normalized(b.name),gx=grams(x),gy=grams(y);
  const name=x===y?1:(2*[...gx].filter(g=>gy.has(g)).length / Math.max(1,gx.size+gy.size));
  const amount=Math.max(a.amount,b.amount)===0?1:Math.min(a.amount,b.amount)/Math.max(a.amount,b.amount);
  const hierarchy=normalized(a.hierarchy)===normalized(b.hierarchy)&&a.hierarchy.length>0?1:0;
  return { score:Math.round((name*.6+amount*.2+hierarchy*.2)*100), name:Math.round(name*100), amount:Math.round(amount*100), hierarchy:hierarchy*100 };
}
export function candidates(rows:BudgetRow[],year:number) {
  return rows.filter(r=>(r.year===year||r.year===year-1)&&r.verified).flatMap(current=>rows.filter(r=>r.year===current.year-1&&r.verified&&r.category===current.category).map(previous=>({current,previous,...lineage(previous,current)})).filter(x=>x.score>=45).sort((a,b)=>b.score-a.score).slice(0,3));
}
