import ts from 'typescript';
import {readFileSync,mkdirSync,writeFileSync} from 'node:fs';
import {dirname} from 'node:path';
import {spawnSync} from 'node:child_process';
for(const file of ['lib/types.ts','lib/analysis.ts','lib/ingest.ts','tests/analysis.test.ts']){
 const target=`work/tests/${file.replace(/\.ts$/,'.js')}`;
 mkdirSync(dirname(target),{recursive:true});
 writeFileSync(target,ts.transpileModule(readFileSync(file,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,esModuleInterop:true}}).outputText);
}
const result=spawnSync(process.execPath,['--test','work/tests/tests/analysis.test.js'],{stdio:'inherit'});process.exit(result.status??1);
