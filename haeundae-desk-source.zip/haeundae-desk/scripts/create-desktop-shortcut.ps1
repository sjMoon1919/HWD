param([Parameter(Mandatory=$true)][string]$Url)
if($Url -notmatch '^https://[a-zA-Z0-9.-]+(?:/.*)?$'){throw 'HTTPS 배포 주소를 입력하세요.'}
$desktopPath=[Environment]::GetFolderPath('Desktop')
$shortcutPath=Join-Path $desktopPath '해운대 데스크.url'
if(Test-Path -LiteralPath $shortcutPath){throw '해운대 데스크 바로가기가 이미 있습니다.'}
@("[InternetShortcut]","URL=$Url") | Set-Content -LiteralPath $shortcutPath -Encoding utf8
Write-Output "바탕화면에 해운대 데스크 바로가기를 만들었습니다. 독립 앱 설치는 브라우저의 앱 설치 메뉴를 사용하세요."
