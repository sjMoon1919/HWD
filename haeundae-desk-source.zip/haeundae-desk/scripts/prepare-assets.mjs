import { cpSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url),root=dirname(require.resolve('pdfjs-dist/package.json'));
mkdirSync('public',{recursive:true});
cpSync(join(root,'build/pdf.worker.min.mjs'),'public/pdf.worker.min.mjs');
for(const name of ['cmaps','standard_fonts'])cpSync(join(root,name),join('public',name),{recursive:true});
